
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohammad
 */
public class ProdcutClass {
    private Integer _ProductId;
    private Integer _CategoryId;
    private String _ProductCode;
    private String _ProductDesc;
    private double _Price;
    private Integer _UnitDesc;

    public Integer getProductId() {
        return _ProductId;
    }

    public void setProductId(Integer _ProductId) {
        this._ProductId = _ProductId;
    }

    public Integer getCategoryId() {
        return _CategoryId;
    }

    public void setCategoryId(Integer _CategoryId) {
        this._CategoryId = _CategoryId;
    }

    public String getProductDesc() {
        return _ProductDesc;
    }

    public void setProductDesc(String _ProductDesc) {
        this._ProductDesc = _ProductDesc;
    }

    public double getPrice() {
        return _Price;
    }

    public void setPrice(double _Price) {
        this._Price = _Price;
    }

    public Integer getUnitDesc() {
        return _UnitDesc;
    }

    public void setUnitDesc(Integer _UnitDesc) {
        this._UnitDesc = _UnitDesc;
    }

    public String getProductCode() {
        return _ProductCode;
    }

    public void setProductCode(String _ProductCode) {
        this._ProductCode = _ProductCode;
    }
    
    
}
