/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohammad
 */
public class WarehouseStockClass {
    private Integer _WarehouseStockId;
    private Integer _ProductId;
    private double _Stock;

    public Integer getWarehouseStockId() {
        return _WarehouseStockId;
    }

    public void setWarehouseStockId(Integer _WarehouseStockId) {
        this._WarehouseStockId = _WarehouseStockId;
    }

    public Integer getProductId() {
        return _ProductId;
    }

    public void setProductId(Integer _ProductId) {
        this._ProductId = _ProductId;
    }

    public double getStock() {
        return _Stock;
    }

    public void setStock(double _Stock) {
        this._Stock = _Stock;
    }
    
}
