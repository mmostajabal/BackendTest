/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohammad
 */
public class Category {
    private Integer _CategoryId;
    private Integer _CategoryDesc;    

    public Integer getCategoryId() {
        return _CategoryId;
    }

    public void setCategoryId(Integer _CategoryId) {
        this._CategoryId = _CategoryId;
    }

    public Integer getCategoryDesc() {
        return _CategoryDesc;
    }

    public void setCategoryDesc(Integer _CategoryDesc) {
        this._CategoryDesc = _CategoryDesc;
    }
    
}
